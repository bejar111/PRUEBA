package pe.area51.locationapp;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private TextView textViewLocation;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewLocation=(TextView) findViewById(R.id.textview_location);
        locationManager=(LocationManager) getSystemService(LOCATION_SERVICE);

    }

    @Override
    protected void onStart() {
        super.onStart();
        //locationManager.getLastKnownLocation()
        //ocationManager.requestLocationUpdates

        final List<String> locationProviders=locationManager.getAllProviders();
        for (final String locationProvider: locationProviders){
            locationManager.requestLocationUpdates(locationProvider,0,0, this);
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        locationManager.removeUpdates(this);
    }


    private void showLocation(final Location location)
    {
        // location.getAccuracy() //precision
        // location.getAltitude() //
        textViewLocation.setText(location.toString());
    }

    @Override
    public void onLocationChanged(Location location) {
        //cada vez q obtiene una ubicacion nueva

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {
        //cada vez q activo un proveedor

    }

    @Override
    public void onProviderDisabled(String s) {
        //cada vez q desactivo un proveedor

    }



}
