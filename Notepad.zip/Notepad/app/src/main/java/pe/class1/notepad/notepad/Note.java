package pe.class1.notepad.notepad;

/**
 * Created by alumno on 23/12/17.
 */

public class Note {
    private final long id;
    private final String tittle;
    private final String content;
    private long creationTimeStamp;

    public Note(long id, String tittle, String content, long creationTimeStamp) {
        this.id = id;
        this.tittle = tittle;
        this.content = content;
        this.creationTimeStamp = creationTimeStamp;
    }

    public long getId() {
        return id;
    }

    public String getTittle() {
        return tittle;
    }

    public String getContent() {
        return content;
    }

    public long getCreationTimeStamp() {
        return creationTimeStamp;
    }
}
