package pe.class1.notepad.notepad;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class NotePad extends AppCompatActivity implements ListFragment.ListFragmentInterface {

    private final static String FRAGMENT_TAG_LIST="fragmemt_list";

    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_pad);
       final ListFragment listFragment=new ListFragment(); //
        //listFragment=new ListFragment(); //

        if(savedInstanceState==null){

            final FragmentManager fragmentManager=getSupportFragmentManager();
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.framelayout_fragment_container,listFragment, FRAGMENT_TAG_LIST)
                    .commit();
        }else  {
            listFragment=(ListFragment) getSupportFragmentManager().findFragmentByTag();
        }
        listFragment.setListFragmentInterface(this);
    }

    @Override
    public void onNoteSelected(Note note){
        //Toast.makeText(this,note.getTittle(),Toast.LENGTH_SHORT).show();
        final ContentFragment contentFragment=ContentFragment.newInstante(note);
        fragmentManager
                .beginTransaction()
                .replace(R.id.framelayout_fragment_container,contentFragment)
                .addToBackStack(null)
                .commit();

    }

}
