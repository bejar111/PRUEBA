package pe.class1.notepad.notepad;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by alumno on 23/12/17.
 */


public class ListFragment extends Fragment {

    public interface ListFragmentInterface()
    {

    }


    private ListView listViewNotes;
    private ListFragmentInterface listFragmentInterface;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        final View view=inflater.inflate(R.layout.fragment_list, container,false);
        listViewNotes= (ListView) view.findViewById(R.id.listview_note);
        final NotesAdapter notesAdapter=new NotesAdapter(getContext());
        notesAdapter.addAll(createTestNotes(100));
        listViewNotes.setAdapter(notesAdapter);

        listViewNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(listFragmentInterface!=null){
                    final Note note=notesAdapter.getItem(i);
                    listFragmentInterface.onNoteSelected(note);
                }
            }
        });
        return view;

    }

    private static List<Note> createTestNotes(final int size){
        final List<Note> notes=new ArrayList<>();

        for (int i=0; i<size; i++){
            final String tittle="Note tittle "+(i+1);
            final String content="This is the content of the number "+(i+1);
            final Note note=new Note(
                    i,
                    tittle,
                    content,
                    System.currentTimeMillis()
                );
            notes.add(note);
            }
       return notes;

    }

    private static class NotesAdapter extends ArrayAdapter<Note>{
        private final LayoutInflater layoutInflater;

        public NotesAdapter (@NonNull final Context context){
            super(context,  0);
            layoutInflater=LayoutInflater.from(context);
        }

        private static class NoteViewHolder{
            private TextView textViewTitle;
            private TextView textViewContent;
        }

        @NonNull
        @Override
        public View getView(int position,
                            @Nullable View convertView,
                            @NonNull ViewGroup parent) {
            final View view;
            final NoteViewHolder noteViewHolder;

            if(convertView==null) {
                view = layoutInflater.inflate(
                        R.layout.element_note,
                        parent, false);
                noteViewHolder=new NoteViewHolder();
                noteViewHolder.textViewTitle=(TextView) view.findViewById(R.id.textview_tittle);
                noteViewHolder.textViewContent=(TextView) view.findViewById(R.id.textview_content);
                view.setTag(noteViewHolder);
            }else{
                view=convertView;
                noteViewHolder=(NoteViewHolder) view.getTag();
            }

            //final TextView textViewTitle=(TextView) view.findViewById(R.id.textview_tittle);
            //final TextView textViewContent=(TextView) view.findViewById(R.id.textview_content);

            final Note note=getItem(position);
            //textViewTitle.setText(note.getTittle());
            //textViewContent.setText(note.getContent());
            noteViewHolder.textViewTitle.setText(note.getTittle());
            noteViewHolder.textViewContent.setText(note.getContent());
            return  view;
        }

    }

}
