package pe.class1.notepad.notepad;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/**
 * Created by alumno on 23/12/17.
 */

public class ContentFragment extends Fragment  {

    private TextView textViewTittle;
    private TextView textViewDate;
    private TextView textViewContent;
    private Note note;



    public static ContentFragment newInstante (final Note note){
        final ContentFragment contentFragment=new ContentFragment();
        final Bundle arguments=new Bundle();
        arguments.putLong("note_id", note.getId());
        arguments.putString("note_tittle",note.getTittle());
        arguments.putString("note_content",note.getContent());
        arguments.putLong("note_creationTimeStamp",note.getCreationTimeStamp());
        contentFragment.setArguments(arguments);
        return contentFragment;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        final Bundle  arguments=getArguments();
        final long id=arguments.getLong("note_id");
        final String tittle=arguments.getString("note_tittle");
        final String content=arguments.getString("note_content");
        final long creationTimeStamp= arguments.getLong("note_creationTimeStamp");
        note=new Note(id,tittle,content,creationTimeStamp);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        final View view=inflater.inflate(R.layout.fragment_content,container,false);
//        textViewTittle =(TextView) view.findViewById(R.id.textview_tittle);
  //      textViewContent =(TextView) view.findViewById(R.id.textview_content);
        //    textViewDate =(TextView) view.findViewById(R.id.textview_date);

        final TextView textViewTittle =(TextView) view.findViewById(R.id.textview_tittle);
        final TextView textViewContent =(TextView) view.findViewById(R.id.textview_content);
        final TextView textViewDate =(TextView) view.findViewById(R.id.textview_date);
        textViewTittle.setText(note.getTittle());
        textViewContent.setText(note.getContent());

        final Date date=new Date(note.getCreationTimeStamp());
        final SimpleDateFormat simpleDateFormat=new SimpleDateFormat("d/M/y", Locale.US);
        final String formatedDate= simpleDateFormat.format(date);
        textViewDate.setText(formatedDate);

        return  view;

    }

    public void setNote(Note note){
        this.note=note;
        if(isVisible()){
            textViewDate.setText(note.getTittle());
        }
    }


}
