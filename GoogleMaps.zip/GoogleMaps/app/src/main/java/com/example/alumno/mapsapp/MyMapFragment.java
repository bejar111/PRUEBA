package com.example.alumno.mapsapp;

import android.os.Bundle;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

/**
 * Created by alumno on 1/20/18.
 */

public class MyMapFragment extends SupportMapFragment implements OnMapReadyCallback {
    private final static int REQUEST_CODECAM_PERMISSION_FINE_LOCATION=1;
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        //googleMap.setMyLocationEnabled(true);
    }


}


