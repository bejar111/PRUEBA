package com.example.alumno.camaraapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private final static int REQUEST_TAKE_PICTURE=100;
    private File pictureFile;
    private ImageView imageViewPicture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageViewPicture=(ImageView) findViewById(R.id.imageview_picture);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final int itemId = item.getItemId();
        switch (itemId) {
            case R.id.action_take_picture:
                    takePicture();
                    return true;
            default:
                return  false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==REQUEST_TAKE_PICTURE && requestCode== RESULT_OK){

            setPicture(pictureFile);
        }
    }

    private File createTempFile(){
        final String filename="picture_"+ System.currentTimeMillis();
        final File storageDir= Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES
        );
        return File.createTempFile(filename,'.jpg',storageDir);

    }

    private void setPicture(final File  pictureFile){
        final Bitmap pictureBitmap= BitmapFactory.decodeFile(pictureFile);
        imageViewPicture.setImageBitmap(pictureBitmap);
    }

    private void takePicture(){
        final Intent intentTakePicure =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(isActivityAvailable(intentTakePicure)){
            try {
                //startActivity(intentTakePicure);
                pictureFile = createTempFile();
                intentTakePicure.putExtra(
                        MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(pictureFile)
                );
                startActivityForResult(intentTakePicure, REQUEST_TAKE_PICTURE);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    private boolean isActivityAvailable(final Intent intent){
        return intent.resolveActivity(getPackageManager())!=null;
    }

}

