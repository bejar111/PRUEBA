package pe.area51.listandcontent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by alumno on 1/6/18.
 */

public class DatabaseManager  extends SQLiteOpenHelper {
    private final static String DATABASE_NAME="notes.db";
    private final static int DATABASE_version=1;

    private static DatabaseManager INSTANCE=null;

    public static DatabaseManager getInstace(final Context context){
        if(INSTANCE==null){
            INSTANCE=new DatabaseManager(context.getApplicationContext());
        }
        return  INSTANCE;
    }

    public DatabaseManager (Context context){
        //super  (context,name,factory,version); factory para el uso del cursor
        //super  (context,DATABASE_NAME,null,DATABASE_version);
        super  (context.getApplicationContext(),DATABASE_NAME,null,DATABASE_version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)  {
        final String databseCreateScript="CREATE TABLE "+ NoteContract.NOTES_TABLE+"( "
                +NoteContract.NOTE_ID+ " INTEGER PRIMARY KEY,"
                +NoteContract.NOTE_TITLE +" TEXT,"
                +NoteContract.NOTE_CONTENT +" TEXT,"
                +NoteContract.NOTE_CREATION_TIMESTAMP +" INTEGER)";
        sqLiteDatabase.execSQL(databseCreateScript);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        throw new RuntimeException("This method shouldn't be called because the databsae version is 1.");
    }

    //
    public long InsertNote(final String title, final String content, final long creationTimestamp)
    {
        final SQLiteDatabase sqLiteDatabase= getWritableDatabase();
        final ContentValues contentValues=new ContentValues();
        contentValues.put(NoteContract.NOTE_TITLE,title);
        contentValues.put(NoteContract.NOTE_CONTENT,content);
        contentValues.put(NoteContract.NOTE_CREATION_TIMESTAMP,creationTimestamp);
        return sqLiteDatabase.insert(NoteContract.NOTES_TABLE, null,  contentValues);
    }

    public List<Note> getNotes(){
        final SQLiteDatabase sqLiteDatabase=getReadableDatabase();
        final Cursor queryCursor=sqLiteDatabase.query(NoteContract.NOTES_TABLE,
                null,
                null,
                null,
                null,
                null,
                null);

        final ArrayList<Note> notes=new ArrayList<>();

        while(queryCursor.moveToNext()){
            final long id=queryCursor.getLong(queryCursor.getColumnIndex(NoteContract.NOTE_ID) );
            final String title=queryCursor.getString(queryCursor.getColumnIndex(NoteContract.NOTE_TITLE) );
            final String content=queryCursor.getString(queryCursor.getColumnIndex(NoteContract.NOTE_CONTENT) );
            final long creationTimestamp=queryCursor.getLong(queryCursor.getColumnIndex(NoteContract.NOTE_CREATION_TIMESTAMP) );

            final Note note =new Note()
                    .setContent(content)
                    .setTitle(id +" - "+title )
                    .setId(id)
                    .setCreationTimestamp(creationTimestamp);
            notes.add(note);
        }
        queryCursor.close();
        return notes;
    }

}
