package pe.area51.listandcontent;

/**
 * Created by alumno on 1/6/18.
 */

public class NoteContract {
    public final static String NOTES_TABLE="notes";
    public final static String NOTE_ID="_id";
    public final static String NOTE_TITLE="title";
    public final static String NOTE_CONTENT="content";
    public final static String NOTE_CREATION_TIMESTAMP="CreationTimeStamp";
}
