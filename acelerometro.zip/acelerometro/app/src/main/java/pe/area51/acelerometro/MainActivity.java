package pe.area51.acelerometro;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private TextView textViewSensorData;
    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewSensorData=(TextView) findViewById(R.id.textview_sensor_data);
        sensorManager=(SensorManager) getSystemService(SENSOR_SERVICE);
    }

    @Override
    protected void onStart() {
        super.onStart();
        final Sensor sensorAccelerometer= sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this,sensorAccelerometer, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    protected void onStop() {
        super.onStop();
        sensorManager.unregisterListener(this);

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        final float x=sensorEvent.values[0];
        final float y=sensorEvent.values[1];
        final float z=sensorEvent.values[2];
        final String xAxis=getString(R.string.x_axis, x);
        final String yAxis=getString(R.string.y_axis, y);
        final String zAxis=getString(R.string.z_axis, z);
        textViewSensorData.setText(
                        xAxis+"\n"+
                        yAxis+"\n"+
                        zAxis+"\n");
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}
